Check what is passed to the recursive function when it is first called.

Recursive functions call themselves. When this function calls itself, what information should it pass itself as a parameter?