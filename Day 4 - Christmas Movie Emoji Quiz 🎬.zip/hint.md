- You can read up on Math.floor and Math.random to help you select an element from an array at random.

- The .splice() method can be useful for removing an element from an array at a given position, but there are other ways of doing this.

- Find a way of making both the player's guess and the correct answer lowercase, so you can easily compare them.