- You will probably want to iterate over santasArr and check if an element is 'Grinch'.

- As you iterate, be sure to keep a track of the index you are on!
(Array methods like .map() and .forEach() have a parameter which does exactly that!).

- Use a let to store the index of the next name from missingNamesArr to be added back to santasArr. 

- You should then be able to use the index of each 'Grinch' to replace 'Grinch' with a missing name.
