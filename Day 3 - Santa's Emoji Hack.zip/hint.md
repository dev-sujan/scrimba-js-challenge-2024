/*

1. Strings in JavaScript has a .startsWith(), .endsWith(), and .slice() methods
   that all will come in handy when solving the first part of this challenge.
2. Split the sentence into words using .split() and then map over them to see 
   if the given word is indeed an emoji shortcode or not.
   
Stretch goal: for this one, you're one your own!    
*/