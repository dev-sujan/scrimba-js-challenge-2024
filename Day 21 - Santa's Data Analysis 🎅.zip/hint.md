As ever, there are many ways of solving this challenge. Here are some pointers for one way to do it.

1. Create an empty object to track the total number of requests for each toy.
2. Loop through "locations" and loop through "toys" for that location.
3. Object.entries could be useful for extracting the information you need.
4. Make sure no toy is repeated in the object you created in step 1.
5. Iterate through that object and track the highest number.

You could also complete this challenge using the .reduce() method.
