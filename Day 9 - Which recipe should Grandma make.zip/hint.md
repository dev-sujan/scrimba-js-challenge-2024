Having trouble getting started? 

The code below is using the filter method to filter the recipes based off of the logic you will create inside the method. Notice the steps within the filter method that help explain the logic path for filtering the recipes correctly.

const suitableRecipes = recipes.filter((recipe) => {

    // Check if the recipe contains at least one favorite ingredient

    // Check if the recipe contains any disliked ingredients

    // Return true if it contains at least one favorite and no dislikes

});

Good luck!