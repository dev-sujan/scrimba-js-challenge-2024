Try to rearrange the characters in the two strings in such a way
that you're able to compare the strings using the equality operator.