Having trouble getting started?

Think about santas change problem as a set of conditonal statements (if, else if, etc). 
When santa delivers to someone and collects payment, what should you check each time? 
You will likely want to know how many of each bill you already have from collecting payment from others so you can determine if you have the correct bills to give change!