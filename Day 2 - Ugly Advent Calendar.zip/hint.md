- Check out https://color.adobe.com/search?q=christmas for some Christmas-themes color pallettes, any of which would be an improvement on the current theme. 😂

- Look up some basics on accessibility ("a11y") and learn how you could improve the a11y of this page, specifically regarding font sizes and color contrasts.

- Stretch goals: consider generating an array of "day" objects that indicate the current state of each day on the calendar. Flip that state when the day is clicked.