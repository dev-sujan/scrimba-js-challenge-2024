- The .includes() method could be super useful here.
- There is a JS method specifically for trimming space from the beginning and end of strings.
- You will likely need to use the .replace() method with some regex.

*** ⚠️ Spoiler Alert! Scroll down if you need extra regex help 🛟 ***





































- This regex /\s{2,}/g matches sequences of two or more consecutive whitespace characters in a string (don't say I never give you anything 😝).