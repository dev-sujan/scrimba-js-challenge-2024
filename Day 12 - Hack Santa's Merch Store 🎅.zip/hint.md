- Search online for Cross Site Scripting (XSS) attack.

- The onclick HTML attribute will likely be helpful! (Although you do have other options.) 

- For the stretch goals, eval() is your friend.

- For the stretch goals, you will likely need to create script tags with createElement().

