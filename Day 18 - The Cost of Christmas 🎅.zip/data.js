export default [
    {
        "item": "Bluetooth Speaker",
        "price": 49.99,
        "isGift": true
    },
    {
        "item": "Office Chair",
        "price": 135.99,
        "isGift": true
    },
    {
        "item": "Gardening Gloves",
        "price": 19.99,
        "isGift": true
    },
    {
        "item": "Moon Cheese",
        "price": 4.99,
        "isGift": false
    },
    {
        "item": "Lifetime supply of olives",
        "price": 299.99,
        "isGift": true
    },
    {
        "item": "Pet Rock",
        "price": 12.99,
        "isGift": true
    },
    {
        "item": "USB Cable",
        "price": 8.99,
        "isGift": false
    },
    {
        "item": "Banana Holder",
        "price": 14.99,
        "isGift": true
    },
    {
        "item": "Can of Paint",
        "price": 28.99,
        "isGift": false
    },
    {
        "item": "Novelty Hot Sauce",
        "price": 25.99,
        "isGift": true
    }
]