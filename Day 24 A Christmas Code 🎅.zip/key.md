abc = klm
xyz = "#$