The coded message is written in binary. How can you convert binary to regular (base 10) numbers?

And what would those numbers mean 🤔 - is it possible that each letter, number and special character has it's own ascii code? Find a way to convert ascii to something readable!

The info in key.md should allow you to figure out what you need to do with those ascii codes 🔮

Final tip: Search online for "Ascii codes table" and look at the printable characters.
