JS
- Create snowflakes with .createElement.
- Give each snowflake a CSS class of "snowflake".
- Use emojis to render the snowflakes. Style them however you like! font-size and animation duration will help 😉
- Add snowflakes to the DOM with appendChild.

CSS
- The snowflakes should be absolutely positioned. 
- The animation should be linear and infinite.
- You could animate this using transform/translate on the Y axis.