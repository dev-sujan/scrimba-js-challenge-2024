###HINTS
- Use an array to store previously generated names.
- Use the Array.find() method to match initials.
- Have a "render" function that updates the UI every time a new name is generated